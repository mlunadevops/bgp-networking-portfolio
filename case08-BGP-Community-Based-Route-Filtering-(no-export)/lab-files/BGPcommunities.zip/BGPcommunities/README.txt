Project: 'case08-BGP-Community-Based-Route-Filtering-(no-export)' created on 2026-08-24
Author: Miguelangel Luna <itgalactelecom@gmail.com>

How to prevent your BGP routes from leaving the neighboring AS without altering the full route? 🛑🌐


In advanced network design, controlling prefix propagation is key. Today I'm sharing a step-by-step guide on how to implement BGP Communities (no-export) to filter and restrict advertisements between autonomous systems in a clean and scalable way.


💡 Swipe through the infographic and check out the attached complete.


¿Cómo evitar que tus rutas BGP salgan del AS vecino sin alterar la ruta completa? 🛑🌐


En diseño de redes avanzado, controlar la propagación de prefijos es clave. Hoy comparto una guía paso a paso sobre cómo implementar BGP Communities (no-export) para filtrar y restringir anuncios entre sistemas autónomos de forma limpia y escalable.

💡 Desliza por la infografía y revisa la guía completa adjunta.